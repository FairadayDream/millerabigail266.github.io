/*
Write a function `removeLastVowel(word)` that takes in a string and returns the
string with its last vowel removed.
*/

function removeLastVowel(word){
    //Sort out the vowels and assign them to a variable .match(regex)
    const allVowel = word.match(/[aeiou]/g);
    //Exclude early the words without allVowel
    if (!allVowel || allVowel.length === 0){
        return word;
    }
    //get the last vowel excluded from the rest & as a variable .pop()
    let excludeThisVowel = allVowel.pop();
    //return the string less the excluded variable but you cant subtract only replace
    return word.replace(excludeThisVowel,'');
}

console.log(removeLastVowel('bootcamp')); // 'bootcmp'
console.log(removeLastVowel('better')); // 'bettr'
console.log(removeLastVowel('graph')); // 'grph'
console.log(removeLastVowel('thy')); // 'thy'
