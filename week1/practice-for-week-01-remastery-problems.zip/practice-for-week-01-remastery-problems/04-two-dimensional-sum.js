/*
Write a function `twoDimensionalSum(arr)` that takes in a 2D array of numbers
and returns the total sum of all numbers.
*/

let twoDimensionalSum = function(arr) {
    let sum = 0; //initializing sum to 0

    for (let i = 0; i < arr.length; i++){ // Outer loop for rows // double loop the bitch cause it a 2D array sum
        let subArr = arr[i];  //give var to index tracking of i

  for (let j = 0; j < subArr.length; j++){ // Inner loop for columns
      sum += subArr[j]; // Accumulate the values into the one variable
   }
}
return sum;
};

let arr1 = [
    [1, 3],
    [-4, 7, 10],
    [2]
];
console.log(twoDimensionalSum(arr1)); // 19

let arr2 = [
    [],
    [3, 1, 2],
];
console.log(twoDimensionalSum(arr2)); // 6
